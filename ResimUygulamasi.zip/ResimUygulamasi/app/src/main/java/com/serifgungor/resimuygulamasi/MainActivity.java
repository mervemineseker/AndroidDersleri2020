package com.serifgungor.resimuygulamasi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    ImageView ivResim;
    TextView tvBaslik;
    Button btnIleri,btnGeri,btnRastgele;

    int sayi=0;
    ArrayList<Resim> resimler = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ivResim = findViewById(R.id.ivResim);
        tvBaslik = findViewById(R.id.tvBaslik);
        btnGeri = findViewById(R.id.btnGeri);
        btnIleri = findViewById(R.id.btnIleri);
        btnRastgele = findViewById(R.id.btnRastgele);

        //int id, String resimBaslik, int resim
        resimler.add(new Resim(1,"Başlık 1",R.drawable.resim1));
        resimler.add(new Resim(2,"Başlık 2",R.drawable.resim2));
        resimler.add(new Resim(3,"Başlık 3",R.drawable.resim3));
        resimler.add(new Resim(4,"Başlık 4",R.drawable.resim4));
        resimler.add(new Resim(5,"Başlık 5",R.drawable.resim5));
        resimler.add(new Resim(6,"Başlık 6",R.drawable.resim6));

        ivResim.setImageResource(resimler.get(0).getResim());
        tvBaslik.setText(resimler.get(0).getResimBaslik());



       btnIleri.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               if(sayi<resimler.size()-1){
                   sayi++;
                   ivResim.setImageResource(resimler.get(sayi).getResim());
                   tvBaslik.setText(resimler.get(sayi).getResimBaslik());
                   //kod ile texview nesnesinin görünen yazısını değiştirir.
               }
           }
       });
       btnRastgele.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Random rnd = new Random();
               sayi = rnd.nextInt(resimler.size());
               ivResim.setImageResource(resimler.get(sayi).getResim());
               tvBaslik.setText(resimler.get(sayi).getResimBaslik());
           }
       });
       btnGeri.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               if(sayi!=0){
                   sayi--;
                   ivResim.setImageResource(resimler.get(sayi).getResim());
                   tvBaslik.setText(resimler.get(sayi).getResimBaslik());
               }

           }
       });




    }
}
